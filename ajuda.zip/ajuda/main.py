
from gerenciamento import cadastrar_livro, editar_livro, excluir_livro, exibir_livros, devolver_livro
from usuarioo import realizar_login, cadastrar_usuario



usuarios = {}
livros = []

def menu_principal():
    while True:
        print('\nBem vindo(a) ao Gerenciamento de Biblioteca!')
        print('\nMenu Principal')
        print('1. Realizar login')
        print('2. Cadastrar Usuário')
        print('3. Sair')
        opcao = input('Escolha uma opção: ')

        if opcao == '1':
            if realizar_login():
                menu_livros()
        elif opcao == '2':
            cadastrar_usuario()
        elif opcao == '3':
            print('Programa encerrado.')
            break
        else:
            print('Opção inválida.')

def menu_livros():
    while True:
        print('\nMenu de Livros')
        print('1. Cadastrar livro') 
        print('2. Editar livro')
        print('3. Excluir livro')   
        print('4. Exibir livros')   
        print('5. Emprestar livro')
        print('6. Devolver livro')
        print('7. Voltar ao menu principal')    
        opcao = input('Escolha uma opção: ') 

        if opcao == '1':
            cadastrar_livro()
        elif opcao == '2':
            editar_livro()
        elif opcao == '3':
            excluir_livro()
        elif opcao == '4':
            exibir_livros()
        elif opcao == '5':
            emprestar_livro()
        elif opcao == '6':
            devolver_livro()
        elif opcao == '7':
            break   
        else:
            print('Opção inválida.')

menu_principal()