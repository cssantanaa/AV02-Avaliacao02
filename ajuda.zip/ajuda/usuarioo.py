def realizar_login():
    print ('\nLogin')
    usuario = input ('Nome de usuário: ').lower()
    senha = input('Senha: ')

    if usuario in usuarios and usuarios[usuario] == senha:
        print('Login realizado com sucesso!')
        return True
    else:
        print('Usuário ou senha incorretos.')
        return False

def cadastrar_usuario():
    print ('\nCadastro de Usuário')  
    while True:  
        usuario = input('Escolha um nome de usuário: ').lower()
        if len(usuario) < 4:
            print('Usuário inválido. O usuário deve conter mais de quatro caracteres.')
            continue
        elif usuario in usuarios:
            print('Este usuário não está disponível. Tente outro nome.')
        else: 
            break

    while True:
        senha = input('Escolha uma senha: ') 
        if len(senha) >= 4:
            usuarios[usuario] = senha
            print('Usuário cadastrado com sucesso!')
            break
        else:
            print('Senha inválida. A senha deve conter mais de quatro caracteres.')
