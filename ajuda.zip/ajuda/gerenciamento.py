def cadastrar_livro():
    print('\nCadastrar Livro')
    titulo = input('Nome do livro: ')
    autor = input('Autor do livro: ')
    ano = input('Ano de publicação: ')
    status = 'Disponível'
    livros.append({'Título': titulo, 'Autor': autor, 'Ano': ano, 'Status': status})
    print('Livro cadastrado com sucesso!')

def editar_livro():
    print('\nEditar Livro') 
    titulo = input('Título do livro a ser editado: ').lower()
    for livro in livros:
        if livro['Título'].lower() == titulo:
            novo_titulo = input('Novo título (deixe vazio para manter): ')
            novo_autor = input('Novo autor (deixe vazio para manter): ')
            novo_ano = input('Novo ano (deixe vazio para manter): ')

            if novo_titulo:
                livro['Título'] = novo_titulo
            if novo_autor:
                livro['Autor'] = novo_autor    
            if novo_ano:
                livro['Ano'] = novo_ano

            print('Livro editado com sucesso!')
            return
    print('Livro não encontrado.')

def excluir_livro():
    print('\nExcluir Livro')
    titulo = input('Título do livro a ser excluído: ').lower()
    for livro in livros:
        if livro['Título'].lower() == titulo:
            livros.remove(livro)
            print('Livro excluído com sucesso!')
            return
    print('Livro não encontrado.')    

def exibir_livros():
    print('\nLista de Livros')
    if not livros:
        print('Nenhum livro cadastrado.')   
    else:
        for livro in livros:
            print(f"Título: {livro['Título']}, Autor: {livro['Autor']}, Ano: {livro['Ano']}, Status: {livro['Status']}")

def emprestar_livro():
    print('\nEmprestar Livro')
    titulo = input('Título do livro a ser emprestado: ').lower()
    for livro in livros:
        if livro['Título'].lower() == titulo and livro['Status'] == 'Disponível':
            livro['Status'] = 'Emprestado'
            print(f"Você emprestou o livro: {livro['Título']}")
            return
    print('Livro não encontrado ou já emprestado.')

def devolver_livro():
    print('\nDevolver livro')
    titulo = input('Título do livro a ser devolvido: ').lower()
    for livro in livros:
        if livro['Título'].lower() == titulo and livro['Status'] == 'Emprestado':
            livro['Status'] = 'Disponível'
            print(f"Você devolveu o livro: {livro['Título']}")
            return
    print('Livro não encontrado ou não estava emprestado.')
